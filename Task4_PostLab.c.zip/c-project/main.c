#include <stdio.h>
void showmenu();
float calculatebill(int units,int category);
float calculatesurcharge(float bill);
void displaybill(int units,float bill,float surcharge);

int main()
{
    int units,category;
    float bill,surcharge;
    showmenu();
    scanf("%d", &category);
    printf("Enter units consumed: ");
    scanf("%d", &units);
    bill=calculatebill(units,category);
    surcharge=calculatesurcharge(bill);
    displaybill(units,bill,surcharge);
    return 0;
}

void showmenu()
{
    printf("Customer category:\n1. Domestic\n2. Commercial\nEnter choice: ");
}

float calculatebill(int units,int category)
{
    float bill;
    if(category==1)
    {
        if(units<=100)
        {
            bill=units*15;
        }
        else
        {
            bill=100*15+(units-100)*20;
        }
    }
    else
    {
        bill=units*25;
    }
    return bill;
}

float calculatesurcharge(float bill)
{
    float surcharge=0;
    if(bill>5000)
    {
        surcharge=bill*0.05;
    }
    return surcharge;
}

void displaybill(int units,float bill,float surcharge)
{
    printf("Units consumed: %d\n", units);
    printf("Bill amount: Rs. %.2f\n", bill);
    printf("Surcharge: Rs. %.2f\n", surcharge);
    printf("Final payable amount: Rs. %.2f\n", bill+surcharge);
}
