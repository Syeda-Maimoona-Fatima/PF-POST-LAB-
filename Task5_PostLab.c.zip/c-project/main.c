#include <stdio.h>
float calculatebonus(float basic,int years);
float calculatetax(float total);
void displaysalary(float basic,float bonus,float tax,float finalsalary);

int main()
{
    float basic,bonus,tax,finalsalary;
    int years;
    printf("Enter basic salary: ");
    scanf("%f", &basic);
    printf("Enter years of service: ");
    scanf("%d", &years);
    bonus=calculatebonus(basic,years);
    tax=calculatetax(basic+bonus);
    finalsalary=basic+bonus-tax;
    displaysalary(basic,bonus,tax,finalsalary);
    return 0;
}

float calculatebonus(float basic,int years)
{
    float bonus;
    if(years>5)
    {
        bonus=basic*0.15;
    }
    else if(years>=3)
    {
        bonus=basic*0.10;
    }
    else
    {
        bonus=basic*0.05;
    }
    return bonus;
}

float calculatetax(float total)
{
    float tax=0;
    if(total>100000)
    {
        tax=total*0.05;
    }
    return tax;
}

void displaysalary(float basic,float bonus,float tax,float finalsalary)
{
    printf("Basic salary: Rs. %.2f\n", basic);
    printf("Bonus: Rs. %.2f\n", bonus);
    printf("Tax: Rs. %.2f\n", tax);
    printf("Final salary: Rs. %.2f\n", finalsalary);
}
