#include <stdio.h>
int getage();
float getsalary();
float getpayments();
int checkeligibility(int age,float salary,float payments);
float calculatemaxloan(float salary,float payments);
void displayresult(int code,float salary,float payments);

int main()
{
    int age,code;
    float salary,payments;
    age=getage();
    salary=getsalary();
    payments=getpayments();
    code=checkeligibility(age,salary,payments);
    displayresult(code,salary,payments);
    return 0;
}

int getage()
{
    int age;
    printf("Enter age: ");
    scanf("%d", &age);
    return age;
}

float getsalary()
{
    float salary;
    printf("Enter monthly salary: ");
    scanf("%f", &salary);
    return salary;
}

float getpayments()
{
    float payments;
    printf("Enter existing monthly loan payments: ");
    scanf("%f", &payments);
    return payments;
}

int checkeligibility(int age,float salary,float payments)
{
    if(age<21)
    {
        return 1;
    }
    if(salary<50000)
    {
        return 2;
    }
    if(salary-payments<0.40*salary)
    {
        return 3;
    }
    return 0;
}

float calculatemaxloan(float salary,float payments)
{
    return 10*(salary-payments);
}

void displayresult(int code,float salary,float payments)
{
    if(code==0)
    {
        printf("Eligible for a loan\n");
        printf("Maximum loan amount: Rs. %.2f\n", calculatemaxloan(salary,payments));
    }
    else if(code==1)
    {
        printf("Not eligible: age must be at least 21\n");
    }
    else if(code==2)
    {
        printf("Not eligible: monthly salary must be at least Rs. 50000\n");
    }
    else
    {
        printf("Not eligible: less than 40%% of salary remains after existing payments\n");
    }
}
