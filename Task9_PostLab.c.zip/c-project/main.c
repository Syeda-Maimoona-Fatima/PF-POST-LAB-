#include <stdio.h>
void showmenu();
void checkbalance(float balance);
float deposit(float balance);
float withdraw(float balance);

int main()
{
    float balance=20000;
    int choice;
    do
    {
        showmenu();
        scanf("%d", &choice);
        if(choice==1)
        {
            checkbalance(balance);
        }
        else if(choice==2)
        {
            balance=deposit(balance);
        }
        else if(choice==3)
        {
            balance=withdraw(balance);
        }
        else if(choice==4)
        {
            printf("Thank you\n");
        }
        else
        {
            printf("Invalid choice\n");
        }
    }
    while(choice!=4);
    return 0;
}

void showmenu()
{
    printf("1.Check Balance  2.Deposit  3.Withdraw  4.Exit  \nEnter choice: ");
}

void checkbalance(float balance)
{
    printf("Current balance: Rs. %.2f\n", balance);
}

float deposit(float balance)
{
    float amount;
    printf("Enter amount to deposit: ");
    scanf("%f", &amount);
    if(amount<=0)
    {
        printf("Invalid amount\n");
    }
    else
    {
        balance=balance+amount;
        printf("Deposit successful. Updated balance: Rs. %.2f\n", balance);
    }
    return balance;
}

float withdraw(float balance)
{
    float amount;
    printf("Enter amount to withdraw: ");
    scanf("%f", &amount);
    if(amount<=0)
    {
        printf("Invalid amount\n");
    }
    else if(amount>balance)
    {
        printf("Insufficient balance\n");
    }
    else if(amount>10000)
    {
        printf("Cannot withdraw more than Rs. 10000 in one transaction\n");
    }
    else
    {
        balance=balance-amount;
        printf("Withdrawal successful. Updated balance: Rs. %.2f\n", balance);
        if(balance<5000)
        {
            printf("Warning: low balance\n");
        }
    }
    return balance;
}
