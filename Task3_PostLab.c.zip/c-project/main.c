#include <stdio.h>
int main()
{
    float temp[2][3][4];
    int ward,patient,reading;
    int count=0;
    float sum,average,highest;
    for(ward=0;ward<2;ward++)
    {
        for(patient=0;patient<3;patient++)
        {
            printf("Ward %d, Patient %d - enter 4 temperatures(in C): ", ward+1,patient+1);
            for(reading=0;reading<4;reading++)
            {
                scanf("%f", &temp[ward][patient][reading]);
            }
        }
    }
    for(ward=0;ward<2;ward++)
    {
        printf("Ward %d\n",ward+1);
        highest=temp[ward][0][0];
        for(patient=0;patient<3;patient++)
        {
            sum=0;
            for(reading=0;reading<4;reading++)
            {
                sum=sum+temp[ward][patient][reading];
                if(temp[ward][patient][reading]>37.5)
                {
                    count++;
                }
                if(temp[ward][patient][reading]>highest)
                {
                    highest=temp[ward][patient][reading];
                }
            }
            average=sum/4;
            printf("Patient %d average temperature: %.2f\n", patient+1,average);
            if(average>38)
            {
                printf("Patient %d average temperature exceeds 38\n", patient+1);
            }
        }
        printf("Highest temperature in Ward %d: %.2f\n", ward+1,highest);
    }
    printf("Readings above 37.5: %d\n",count);
    return 0;
}
