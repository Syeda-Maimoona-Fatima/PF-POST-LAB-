#include <stdio.h>
int main()
{
    int sales[2][3][4];
    int branch,product,week;
    int producttotal,branchtotal,weektotal;
    int highestproduct,topproduct;
    int highestbranch=-1,topbranch=0;
    int highestweek = -1,topweek=0;
    for(branch=0;branch<2;branch++)
    {
        for(product=0;product<3;product++)
        {
            printf("Branch %d, Product %d - enter sales of 4 weeks: ", branch+1,product+1);
            for(week=0;week<4;week++)
            {
                scanf("%d", &sales[branch][product][week]);
            }
        }
    }
    for(branch=0;branch<2;branch++)
    {
        printf("Branch %d\n",branch+1);
        branchtotal=0;
        highestproduct= -1;
        for(product=0;product<3;product++)
        {
            producttotal =0;
            for(week=0;week<4;week++)
            {
                producttotal= producttotal+sales[branch][product][week];
            }
            printf("Product %d total sold: %d\n", product+1, producttotal);
            if(producttotal>highestproduct)
            {
                highestproduct= producttotal;
                topproduct =product+1;
            }
            branchtotal = branchtotal+ producttotal;
        }
        printf("Highest selling product: Product %d\n", topproduct);
        printf("Branch total: %d\n", branchtotal);
        if(branchtotal> highestbranch)
        {
            highestbranch= branchtotal;
            topbranch= branch+ 1;
        }
    }
    for(week=0;week<4;week++)
    {
        weektotal =0;
        for(branch=0;branch<2;branch++)
        {
            for(product=0;product<3;product++)
            {
                weektotal =weektotal+ sales[branch][product][week];
            }
        }
        if(weektotal >highestweek)
        {
            highestweek =weektotal;
            topweek = week+1;
        }
    }
    printf("Week with highest overall sales: Week %d\n",topweek);
    printf("Branch that sold the greatest quantity: Branch %d\n", topbranch);
    return 0;
}
