#include <stdio.h>
int main()
{
    int studentmarks[2][3][4];
    int section,std,sub;
    int total,topstudent,highesttotal;
    int count=0;
    int sectionsum,bestsection=1;
    float avg,sectionavg,bestsectionAvg=0;
    for(section=0;section<2;section++)
    {
        for(std=0;std<3;std++)
        {
            printf("Section %d, Student %d -enter marks of 4 subjects: ",section+1,std+1);
            for(sub=0;sub<4;sub++)
            {
                scanf("%d",&studentmarks[section][std][sub]);
            }
        }
    }
    for(section=0;section<2;section++)
    {
        printf("Section %d\n",section+1);
        sectionsum=0;
        highesttotal=-1;
        for(std=0;std<3;std++)
        {
            total=0;
            for(sub=0;sub<4;sub++)
            {
                total=total+studentmarks[section][std][sub];
            }
            avg= total/4.0;
            printf("Student %d: Total = %d, Average = %.2f\n",std+1,total,avg);
            if(avg>=50)
            {
                count++;
            }
            if(total>highesttotal)
            {
                highesttotal=total;
                topstudent =std+1;
            }
            sectionsum= sectionsum+total;
        }
        printf("Highest scoring student: Student %d\n", topstudent);
        sectionavg =sectionsum/12.0;
        printf("Section average: %.2f\n",sectionavg);
        if (sectionavg > bestsectionAvg)
        {
            bestsectionAvg =sectionavg;
            bestsection=section+1;
        }
    }
    printf("Students with average >= 50: %d\n",count);
    printf("Section with highest overall average: Section %d\n",bestsection);
    return 0;
}
