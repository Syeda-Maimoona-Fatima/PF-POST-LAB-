#include <stdio.h>
float basecharge(float weight);
float distancecharge(float distance);
float memberdiscount(float total,int member);
void displaybill(float base,float distancecost,float discount);

int main()
{
    float weight,distance,base,distancecost,discount;
    int member;
    printf("Enter parcel weight (kg): ");
    scanf("%f", &weight);
    printf("Enter delivery distance (km): ");
    scanf("%f", &distance);
    printf("Member? (1 = Yes, 0 = No): ");
    scanf("%d", &member);
    base=basecharge(weight);
    distancecost=distancecharge(distance);
    discount=memberdiscount(base+distancecost,member);
    displaybill(base,distancecost,discount);
    return 0;
}

float basecharge(float weight)
{
    float base;
    if(weight<=2)
    {
        base=200;
    }
    else if(weight<=5)
    {
        base=400;
    }
    else
    {
        base=700;
    }
    return base;
}

float distancecharge(float distance)
{
    float cost=0;
    if(distance>10)
    {
        cost=distance*20;
    }
    return cost;
}

float memberdiscount(float total,int member)
{
    float discount=0;
    if(member==1 && total>1000)
    {
        discount=total*0.10;
    }
    return discount;
}

void displaybill(float base,float distancecost,float discount)
{
    printf("Base charges: Rs. %.2f\n", base);
    printf("Distance charges: Rs. %.2f\n", distancecost);
    printf("Discount: Rs. %.2f\n", discount);
    printf("Final amount: Rs. %.2f\n", base+distancecost-discount);
}
