#include <stdio.h>
float calculatesubtotal(float price,int quantity);
float bulkdiscount(float subtotal);
float memberdiscount(float subtotal,int member);
float paymentfee(float amount,int card);
void displaybill(float subtotal,float discount1,float discount2,float fee,float finalamount);

int main()
{
    float price,subtotal,discount1,discount2,fee,afterdiscount;
    int quantity,member,card;
    printf("Enter product price: ");
    scanf("%f", &price);
    printf("Enter quantity: ");
    scanf("%d", &quantity);
    printf("Member? (1 = Yes, 0 = No): ");
    scanf("%d", &member);
    printf("Pay by card? (1 = Yes, 0 = No): ");
    scanf("%d", &card);
    subtotal=calculatesubtotal(price,quantity);
    discount1=bulkdiscount(subtotal);
    discount2=memberdiscount(subtotal,member);
    afterdiscount=subtotal-discount1-discount2;
    fee=paymentfee(afterdiscount,card);
    displaybill(subtotal,discount1,discount2,fee,afterdiscount+fee);
    return 0;
}

float calculatesubtotal(float price,int quantity)
{
    return price*quantity;
}

float bulkdiscount(float subtotal)
{
    float discount=0;
    if(subtotal>5000)
    {
        discount=subtotal*0.10;
    }
    return discount;
}

float memberdiscount(float subtotal,int member)
{
    float discount=0;
    if(member==1)
    {
        discount=subtotal*0.05;
    }
    return discount;
}

float paymentfee(float amount,int card)
{
    float fee=0;
    if(card==1)
    {
        fee=amount*0.02;
    }
    return fee;
}

void displaybill(float subtotal,float discount1,float discount2,float fee,float finalamount)
{
    printf("Subtotal: Rs. %.2f\n", subtotal);
    printf("Discount (over 5000): Rs. %.2f\n", discount1);
    printf("Member discount: Rs. %.2f\n", discount2);
    printf("Card payment fee: Rs. %.2f\n", fee);
    printf("Final payable amount: Rs. %.2f\n", finalamount);
}
